package algstudent.s7;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;


//algorithm based on calculating the row values, it could be applied in the other way around
public class NumericSquareBaBSolver {

	public static void main(String[] args) {
		String text = "src/algstudent/s7/test01.txt";
		NumericSquareBaB numericSquare = new NumericSquareBaB(text);

		branchAndBoundOneSolution(numericSquare);

	}

	public static void branchAndBoundOneSolution(NumericSquareBaB numericSquare) {

		String [] rowOperations=numericSquare.getRowOperations();

		getMatrixValues(rowOperations, numericSquare);

		Node rootNode = getHeuristic(numericSquare.getValueMatrix(),numericSquare);
		PriorityQueue<Node> priorityQueue = new PriorityQueue<>(new NodeComparator());
		priorityQueue.add(rootNode);

		branchAndBound(priorityQueue, numericSquare);
	}

	private static void branchAndBound(PriorityQueue<Node> priorityQueue, NumericSquareBaB numericSquare) {
		while (!priorityQueue.isEmpty()) {
			Node node = priorityQueue.poll();
			if (node.isSolution()) { //&& node.getHeuristicValue()==0
				printMatrix(node.getMatrix());
				break;
			} else {
				List<Node> children = node.getChildren(numericSquare);
				for (Node child : children) {
					priorityQueue.add(child);
				}
			}
		}
	}

	/*private static boolean isValidMatrix(int[][] matrix, NumericSquareBaB numericSquare) {
		for (int i = 0; i < matrix.length; i++) {

	        if (!isValidCol(matrix, numericSquare.getColumnOperations()[i], i)) {
	            return false;
	        }
	    }
	    return true;
	}*/

	//used to obtain the rootnode and its heuristic 
	private static Node getHeuristic(int[][] matrix, NumericSquareBaB numericSquare) {
		int count = 0;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				if (matrix[i][j] == -1) {
					count += 1;
				}
			}
		}

		return new Node(matrix, count, null);
	}


	//sets the matrix of values in NumericSquares
	public static void getMatrixValues(String [] rowOperations, NumericSquareBaB numericSquare){

		int [][] matrix = new int[rowOperations.length][getValues(rowOperations[0]).size()];

		for( int i =0; i< rowOperations.length;i++) {

			List<Integer> row = getValues(rowOperations[i]);

			for(int j=0; j<row.size();j++) {
				matrix[i][j]=row.get(j);
			}
		}

		numericSquare.setValueMatrix(matrix);
	}


	/*Get the values of the operation, the ones we are interested in computing*/
	private static List<Integer> getValues(String operation) {
		String[] parts = operation.split("=");

		String operationValuesNoResult=parts[0];
		List<Integer> operationValues = new ArrayList<>();

		for (int i = 0; i < operationValuesNoResult.length(); i += 2) { // Increment by 2 to skip operators
			char valueAsChar = operationValuesNoResult.charAt(i);
			if (valueAsChar == '?') {
				operationValues.add(-1);
			}
			else if (valueAsChar == '=') {
				return operationValues;
			} 
			else {
				int value = Character.getNumericValue(valueAsChar);
				operationValues.add(value);
			}
		}
		return operationValues;
	}

	/*Gets the operators of a operation except =*/
	private static List<Character> getOperators(String operation) {

		String[] parts = operation.split("=");

		String operationOperatorsNoEquals=parts[0];

		List<Character> operationOperators = new ArrayList<>();
		operationOperators.add(' ');

		for (int i = 1; i < operationOperatorsNoEquals.length(); i += 2) { // Increment by 2 to skip operators
			char operator=operationOperatorsNoEquals.charAt(i);

			operationOperators.add(operator);
		}

		return operationOperators;
	}

	private static int getExpectedResult(String operation) {
		String[] parts = operation.split("=");
		return Integer.parseInt(parts[1].trim());
	}

	static boolean isValidRow(int[][] aux, String operation,int rowIndex) {

		List<Character> operators = getOperators(operation);
		int expectedValue= getExpectedResult(operation);

		int result = calculateRowResult(aux,operators,rowIndex);

		return expectedValue==result;
	}

	static boolean isValidCol(int[][] aux, String operation,int colIndex) {

		List<Character> operators = getOperators(operation);
		int expectedValue= getExpectedResult(operation);

		int result = calculateColResult(aux,operators,colIndex);

		return expectedValue==result;
	}


	/*Calculates the result of a given set of values, given the operators of the original operation
	 * 
	 * Uses recursion storing result and passing the operators
	 */
	private static int calculateRowResult(int[][] aux, List<Character> operators, int rowIndex) {

		int[] values = aux[rowIndex];


		int result = values[0];
		for (int i = 1; i < values.length; i++) {
			char operator = operators.get(i);
			int value = values[i];

			if (value != -1) { // Check if the value is not a placeholder
				result = calculateResult(result, value, operator);
			}
		}
		return result;
	}

	private static int calculateColResult(int[][] aux, List<Character> operators, int colIndex) {

		int numRows = aux.length;
		int[] values = new int[numRows];


		for (int i = 0; i < numRows; i++) {
			values[i] = aux[i][colIndex];
		}


		int result = values[0];
		for (int i = 1; i < values.length; i++) {
			char operator = operators.get(i);
			int value = values[i];

			if (value != -1) { // Check if the value is not a placeholder
				result = calculateResult(result, value, operator);
			}
		}
		return result;
	}

	/*Logic for the operators, a is the accumulative result, b is the next evaluated value*/
	private static int calculateResult(int a, Integer b, Character operator) {
		if(operator=='+')
			return a+b;
		else if(operator=='-')
			return a-b;
		else if(operator=='*')
			return a*b;
		else if(operator=='/')
			if(b==0 || a % b!=0 ) {
				return 0;
			}
			else 
				return a/b;
		else
			throw new IllegalArgumentException("Invalid operator");
	}

	@SuppressWarnings("unused")
	private static void printDetails(List<Integer> values, List<Character> operators, int expectedValue, String operation) {
		System.out.println("Operation:  " + operation);
		System.out.print("Values: ");
		for (int value : values) {
			if (value == -1) {
				System.out.print("? ");
			} else {
				System.out.print(value + " ");
			}
		}
		System.out.println();

		System.out.print("Operators: ");
		for (char operator : operators) {
			System.out.print(operator + " ");
		}
		System.out.println();

		System.out.println("Expected Result: " + expectedValue);
		System.out.println();
	}


	static void printMatrix(int[][] matrix) {
		int rows = matrix.length;
		int cols = matrix[0].length;

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println();
	}


	static void printMatrixOfMatrixes(List<List<List<Integer>>> matrixes) {
		for (List<List<Integer>> matrix : matrixes) {
			for (List<Integer> row : matrix) {
				System.out.println(row);
			}
			System.out.println();
			System.out.println();
		}
	}

}
