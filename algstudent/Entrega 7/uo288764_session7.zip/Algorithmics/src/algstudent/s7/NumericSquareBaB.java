package algstudent.s7;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class NumericSquareBaB {

	String text;
	private int size;
	private String[][] matrix;
	private int[][] valueMatrix;

	private String [] rowOperations;
	private String [] columnOperations;
	private int numberOfSols;

	public NumericSquareBaB(String text) {
		this.text=text;
		this.numberOfSols=0;

		createMatrix(text);

		setRowOperations(rowOperations(matrix));
		setColumnOperations(columnOperations(matrix));

	}

	private String [] columnOperations(String [][]matrix) {
		String aux="";

		for(int j=0;j<size;j+=2) {
			for(int i=0;i<size;i++) {
				if(j!=matrix.length-1)
					aux+=matrix[i][j];
			}
			aux+= " ";
		}
		return aux.split(" ");
	}

	private String [] rowOperations(String [][]matrix) {
		String aux="";

		for(int i=0;i<size;i+=2) {
			for(int j=0;j<size;j++) {
				if(i!=matrix.length-1)
					aux+=matrix[i][j];
			}
			aux+= " ";
		}
		return aux.split(" ");
	}


	public void printMatrix() {

		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				if(matrix[i][j]!=null)
					System.out.print(matrix[i][j] +" ");
				else 
					System.out.print("  ");
			}
			System.out.println();
		}
	}

	private void createMatrix(String file) {

		BufferedReader reader = null;	

		try {
			reader = new BufferedReader(new FileReader(file));
			this.size = Integer.parseInt(reader.readLine()); 
			size=size*2+1;


			this.matrix = new String[this.size][this.size];

			int counter=0;
			while (reader.ready()) {
				String[] parts = reader.readLine().split(" ");

				if(counter%2==0 && counter!=size-1) {
					for(int i=0;i<parts.length;i++) {
						matrix[counter][i]=parts[i];
					}
					counter++;
				}
				else {
					int j = 0;
					for (int i = 0; i < parts.length; i += 1) {
						matrix[counter][j]=parts[i];
						j=j+2;
					}
					counter++;
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public String [][] getMatrix() {
		return matrix;
	}

	public String [] getRowOperations() {
		return rowOperations;
	}

	private void setRowOperations(String [] rowOperations) {
		this.rowOperations = rowOperations;
	}

	public String [] getColumnOperations() {
		return columnOperations;
	}

	private void setColumnOperations(String [] columnOperations) {
		this.columnOperations = columnOperations;
	}

	public int getNumberOfSols() {
		return numberOfSols;
	}

	public void setNumberOfSols(int numberOfSols) {
		this.numberOfSols = numberOfSols;
	}

	public int[][] getValueMatrix() {
		return valueMatrix;
	}

	public void setValueMatrix(int[][] matrix2) {
		this.valueMatrix = matrix2;
	}


}


