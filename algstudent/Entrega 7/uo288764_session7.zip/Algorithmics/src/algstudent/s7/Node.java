package algstudent.s7;

import java.util.ArrayList;
import java.util.List;

public class Node {
	public int[][] matrix;
	public int heuristicValue;
	public Node parent;

	private static int minValue=0;
	private static int maxValue=9;

	public Node(int[][] matrix, int heuristicValue, Node parent) {
		this.matrix = matrix;
		this.heuristicValue = heuristicValue;
		this.parent = parent;
	}

	//in charge of creating the children of the provided nodes
	public List<Node> getChildren(NumericSquareBaB numericSquare) {
		List<Node> children = new ArrayList<>();

		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				if (matrix[i][j] == -1) {
					for (int num = minValue; num <= maxValue; num++) {
						int[][] newMatrix = copyMatrix(matrix);
						newMatrix[i][j] = num;
						Node child = new Node(newMatrix, Integer.MAX_VALUE, this);

						child.heuristicValue = calculateHeuristic(newMatrix,numericSquare);
						children.add(child);                           
					}                    
				}
			}
		}
		return children;
	}

	static void printMatrix(int[][] matrix) {
		int rows = matrix.length;
		int cols = matrix[0].length;

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println();
	}

	private static int[][] copyMatrix(int[][] matrix) {
		int rows = matrix.length;
		int cols = matrix[0].length;
		int[][] newMatrix = new int[rows][cols];

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				newMatrix[i][j] = matrix[i][j];
			}
		}

		return newMatrix;
	}

	//heuristic baed on the sum of invalid rows and columns of the madrix if the node matrix has 
	//heuristci 0 it is the correct value
	private int calculateHeuristic(int[][] newMatrix, NumericSquareBaB numericSquare) {
		int invalidRows = 0;
		int invalidCols = 0;

		for (int i = 0; i < matrix.length; i++) {
			if (!isValidRow(newMatrix, numericSquare.getRowOperations()[i], i)) {
				invalidRows++;
			}

			if (!isValidCol(newMatrix, numericSquare.getColumnOperations()[i], i)) {
				invalidCols++;
			}
		}
		return invalidRows + invalidCols;
	}

	private boolean isValidCol(int[][] matrix, String operation, int col) {
		return NumericSquareBaBSolver.isValidCol(matrix, operation, col);
	}

	private boolean isValidRow(int[][] matrix, String operation, int row) {
		return NumericSquareBaBSolver.isValidRow(matrix, operation, row);
	}

	public boolean isSolution() {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				if (matrix[i][j] == -1) {
					return false;
				}
			}
		}
		return true;
	}

	public Node getParent() {
		return parent;
	}

	public int getHeuristicValue() {
		return heuristicValue;
	}

	public int[][] getMatrix() {
		return matrix;
	}

	public int compareTo(Node other) {
		return Integer.compare(this.heuristicValue, other.heuristicValue);
	}
}