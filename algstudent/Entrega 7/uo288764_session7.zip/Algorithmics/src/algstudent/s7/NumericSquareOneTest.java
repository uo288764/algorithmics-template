package algstudent.s7;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class NumericSquareOneTest {

	@BeforeEach
    public void printSeparator() {
        System.out.println("----------------------------------------------");
    }
	
	@Test
	void test00() {
	    String text = "src/algstudent/s7/test00.txt";
	    NumericSquareBaB numericSquare = new NumericSquareBaB(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareBaBSolver.branchAndBoundOneSolution(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    System.out.println("test00 - Execution time: " + executionTime + " ms.");
	   
	}

	@Test
	void test01() {
	    String text = "src/algstudent/s7/test01.txt";
	    NumericSquareBaB numericSquare = new NumericSquareBaB(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareBaBSolver.branchAndBoundOneSolution(numericSquare);
	    long endTime = System.currentTimeMillis();
	    long executionTime = endTime - startTime;
	    
	    System.out.println("test01 - Execution time: " + executionTime + " ms.");
	    
	}

	@Test
	void test02() {
	    String text = "src/algstudent/s7/test02.txt";
	    NumericSquareBaB numericSquare = new NumericSquareBaB(text);
	    
	    long startTime = System.currentTimeMillis();
	     NumericSquareBaBSolver.branchAndBoundOneSolution(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    System.out.println("test02 - Execution time: " + executionTime + " ms.");
	    
	}

	@Test
	void test03() {
	    String text = "src/algstudent/s7/test03.txt";
	    NumericSquareBaB numericSquare = new NumericSquareBaB(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareBaBSolver.branchAndBoundOneSolution(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    System.out.println("test03 - Execution time: " + executionTime + " ms.");
	    
	}

	@Test
	void test04() {
	    String text = "src/algstudent/s7/test04.txt";
	    NumericSquareBaB numericSquare = new NumericSquareBaB(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareBaBSolver.branchAndBoundOneSolution(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    System.out.println("test04 - Execution time: " + executionTime + " ms.");
	    
	}

	@Test
	void test05() {
	    String text = "src/algstudent/s7/test05.txt";
	    NumericSquareBaB numericSquare = new NumericSquareBaB(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareBaBSolver.branchAndBoundOneSolution(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    System.out.println("test05 - Execution time: " + executionTime + " ms.");
	   
	}

	@Test
	void test06() {
	    String text = "src/algstudent/s7/test06.txt";
	    NumericSquareBaB numericSquare = new NumericSquareBaB(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareBaBSolver.branchAndBoundOneSolution(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    System.out.println("test06 - Execution time: " + executionTime + " ms.");
	    
	}

	//@Test
	void test07() {
	    String text = "src/algstudent/s7/test07.txt";
	    NumericSquareBaB numericSquare = new NumericSquareBaB(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareBaBSolver.branchAndBoundOneSolution(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    System.out.println("test07 - Execution time: " + executionTime + " ms.");
	    
	}

}
