package algstudent.s3;

public class Division5 {

}
