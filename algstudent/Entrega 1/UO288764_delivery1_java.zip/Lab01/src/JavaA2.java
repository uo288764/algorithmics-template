
import java.util.ArrayList;

public class JavaA2 {

	
	public static void main(String[] args) {
        javaA2();
    }
	
	public static void javaA2() {
		
		long start = System.currentTimeMillis();
		
		int n= 10000;
		for(int casos=0; casos<=7;casos++) {
			
			listadoPrimos(n);
			//ArrayList <Integer> aux = listadoPrimos(n);
			//System.out.println(aux.toString());
			
			long finish = System.currentTimeMillis();
			long timeElapsed = finish - start;

			System.out.println("n = "+ n + " *** "+ " time = "+ timeElapsed + " milliseconds");
			n*=2;
		}
		
		
	}
	
	public static boolean primoA2( int number ) {
		for(int i=2;i<number;i++) {
			if(number%i==0)
				return false;
		}
		return true;
	}
	
	public static ArrayList <Integer> listadoPrimos(int number) {
		ArrayList<Integer> aux = new ArrayList <>() ;
		
		for(int i = 2;i<=number;i++) {
			if(primoA2(i)) {
				aux.add(i);
			}
		}
		
		return aux;
	}

}

