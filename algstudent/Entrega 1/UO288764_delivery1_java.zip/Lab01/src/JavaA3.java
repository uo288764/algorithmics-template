
import java.util.ArrayList;

public class JavaA3 {

	
	public static void main(String[] args) {
        javaA3();
    }
	
	public static void javaA3() {
		
		long start = System.currentTimeMillis();
		
		int n= 10000;
		for(int casos=0; casos<=7;casos++) {
			
			listadoPrimos(n);
			//ArrayList <Integer> aux = listadoPrimos(n);
			//System.out.println(aux.toString());
			
			long finish = System.currentTimeMillis();
			long timeElapsed = finish - start;

			System.out.println("n = "+ n + " *** "+ " time = "+ timeElapsed + " milliseconds");
			n*=2;
		}
		
		
	}
	
	public static boolean primoA3(int m) {
        for (int i = 2; i <= m / 2; i++) {
            if (m % i == 0) {
                return false;
            }
        }
        return true;
    }
	
	public static ArrayList <Integer> listadoPrimos(int number) {
		ArrayList<Integer> aux = new ArrayList <>() ;
		
		for(int i = 2;i<=number;i++) {
			if(primoA3(i)) {
				aux.add(i);
			}
		}
		
		return aux;
	}

}
