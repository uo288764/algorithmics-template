import java.util.ArrayList;

public class JavaA1 {

	
	public static void main(String[] args) {
        javaA1();
    }
	
	public static void javaA1() {
		
		long start = System.currentTimeMillis();
		
		int n= 10000;
		for(int casos=0; casos<=7;casos++) {
			
			listadoPrimos(n);
			//ArrayList <Integer> aux = listadoPrimos(n);
			//System.out.println(aux.toString());
			
			long finish = System.currentTimeMillis();
			long timeElapsed = finish - start;

			System.out.println("n = "+ n + " *** "+ " time = "+ timeElapsed + " milliseconds");
			n*=2;
		}
		
		
	}
	
	
	 public static boolean primoA1(int m) {
	        boolean p = true;
	        for (int i = 2; i < m; i++) {
	            if (m % i == 0) {
	                p = false;
	            }
	        }
	        return p;
	    }
	
	public static ArrayList <Integer> listadoPrimos(int number) {
		ArrayList<Integer> aux = new ArrayList <>() ;
		
		for(int i = 2;i<=number;i++) {
			if(primoA1(i)) {
				aux.add(i);
			}
		}
		
		return aux;
	}

}
