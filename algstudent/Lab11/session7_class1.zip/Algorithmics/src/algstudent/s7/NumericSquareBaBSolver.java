package algstudent.s7;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

//algorithm based on calculating the row values, it could be applied in the other way around
public class NumericSquareBaBSolver {

	private static int minNum=0;
	private static int maxNum=9;

	public static void main(String[] args) {
		String text = "src/algstudent/s6/test05.txt";
		NumericSquareBaB numericSquare = new NumericSquareBaB(text);

		numericSquareOne(numericSquare);
		

	}

	public static void numericSquareOne(NumericSquareBaB numericSquare){
		
		String[] rowOperations = numericSquare.getRowOperations();
	    String[] colOperations = numericSquare.getColumnOperations();
	    
	    List<List<List<Integer>>> rowSolutions = getRowOrColResults(rowOperations);
	    
	    // normal boolean doesnt work, bc. it cant be modified during recursion
	    AtomicBoolean foundMatrix = new AtomicBoolean(false);
	    
	    // list of matrixes with all possible row solutions
	    generateFirstValidMatrix(rowSolutions, 0, new ArrayList<>(), colOperations, numericSquare, foundMatrix);
	}

	private static void generateFirstValidMatrix(List<List<List<Integer>>> rowSolutions, int row, List<List<Integer>> currentMatrix, String[] colOperations, NumericSquareBaB numericSquare, AtomicBoolean foundMatrix) {
	    
		//once the first was found, no more actions are needed
	    if (foundMatrix.get()) {
	        return;
	    }
	    
	    // If its the last row check if valid
	    if (row == rowSolutions.size() - 1) {
	        for (List<Integer> rowSol : rowSolutions.get(row)) {
	            List<List<Integer>> matrix = new ArrayList<>(currentMatrix);
	            matrix.add(rowSol);
	            if (isValidMatrix(matrix, colOperations)) {
	                printMatrix(matrix);
	                
	                foundMatrix.set(true); //if valid print, set foundMatrix to ture
	                return;
	            }
	        }
	        return;
	    }

	    // Recursively generate matrixes for the next row
	    for (List<Integer> rowSol : rowSolutions.get(row)) {
	        List<List<Integer>> updatedMatrix = new ArrayList<>(currentMatrix);
	        updatedMatrix.add(rowSol);
	        generateFirstValidMatrix(rowSolutions, row + 1, updatedMatrix, colOperations, numericSquare, foundMatrix);
	    }
	}
	

	//for a given matrix checks if those values are also valid for column results
	private static boolean isValidMatrix(List<List<Integer>> matrix, String[] rowOrColOperations) {
		
		//printMatrix(matrix);
		
		for(int j=0; j<matrix.size();j++) {
			List <Integer>column= new ArrayList<>();
			for(int i=0; i<matrix.size();i++) {
				column.add( matrix.get(i).get(j) );
			}
			if(!isValidRowOrColumn(column, rowOrColOperations[j])){
				return false;
			}
		}
		
		return true;
	}

	//checks if the values are valid for a given column or row
	private static boolean isValidRowOrColumn(List<Integer> values, String operation) {
		
		List<Character> operators = getOperators(operation);
		int expectedValue= getExpectedResult(operation);
		
		int result = calculateResult(values, operators);
		
		return expectedValue==result;
	}

	/*
	 *gets the list of all results of the operations of a matrix rows or columns
	 */
	private static List<List<List<Integer>>> getRowOrColResults(String [] rowOrColOperations) {

		List<List<List<Integer>>> rowOrColSolutions = new ArrayList<>();

		for(String operation : rowOrColOperations) {
			rowOrColSolutions.add(getOperationResults(operation));
		}

		return rowOrColSolutions;
	}

	

	/*Get the values of the operation, the ones we are interested in computing*/
	private static List<Integer> getValues(String operation) {
		String[] parts = operation.split("=");

		String operationValuesNoResult=parts[0];
		List<Integer> operationValues = new ArrayList<>();

		for (int i = 0; i < operationValuesNoResult.length(); i += 2) { // Increment by 2 to skip operators
			char valueAsChar = operationValuesNoResult.charAt(i);
			if (valueAsChar == '?') {
				operationValues.add(-1);
			}
			else if (valueAsChar == '=') {
				return operationValues;
			} 
			else {
				int value = Character.getNumericValue(valueAsChar);
				operationValues.add(value);
			}
		}
		return operationValues;
	}

	/*Gets the operators of a operation except =*/
	private static List<Character> getOperators(String operation) {

		String[] parts = operation.split("=");

		String operationOperatorsNoEquals=parts[0];

		List<Character> operationOperators = new ArrayList<>();
		operationOperators.add(' ');

		for (int i = 1; i < operationOperatorsNoEquals.length(); i += 2) { // Increment by 2 to skip operators
			char operator=operationOperatorsNoEquals.charAt(i);

			operationOperators.add(operator);
		}

		return operationOperators;
	}

	

	/*Calculates the result of a given set of values, given the operators of the original operation
	 * 
	 * Uses recursion storing result and passing the operators
	 */
	private static int calculateResult(List<Integer> values, List<Character> operators) {
		int result = values.get(0);
		for (int i = 1; i < values.size(); i++) {
			char operator = operators.get(i);
			int value = values.get(i);

			if (value != -1) { // Check if the value is not a placeholder
				result = calculateResult(result, value, operator);
			}
		}
		return result;
	}

	/*Logic for the operators, a is the accumulative result, b is the next evaluated value*/
	private static int calculateResult(int a, Integer b, Character operator) {
		if(operator=='+')
			return a+b;
		else if(operator=='-')
			return a-b;
		else if(operator=='*')
			return a*b;
		else if(operator=='/')
			if(b==0 || a%b!=0 ) {
				return 0;
			}
			else 
				return a/b;
		else
			throw new IllegalArgumentException("Invalid operator");
	}

	@SuppressWarnings("unused")
	private static void printDetails(List<Integer> values, List<Character> operators, int expectedValue, String operation) {
		System.out.println("Operation:  " + operation);
		System.out.print("Values: ");
		for (int value : values) {
			if (value == -1) {
				System.out.print("? ");
			} else {
				System.out.print(value + " ");
			}
		}
		System.out.println();

		System.out.print("Operators: ");
		for (char operator : operators) {
			System.out.print(operator + " ");
		}
		System.out.println();

		System.out.println("Expected Result: " + expectedValue);
		System.out.println();
	}

	
	 static void printMatrix(List<List<Integer>> matrix) {
		for (List<Integer> row : matrix) {
			System.out.println(row);
		}
		System.out.println();
	}
	
	
	 static void printMatrixOfMatrixes(List<List<List<Integer>>> matrixes) {
		for (List<List<Integer>> matrix : matrixes) {
			for (List<Integer> row : matrix) {
				System.out.println(row);
			}
			System.out.println();
		System.out.println();
		}
	}

}
