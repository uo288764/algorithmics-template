package algstudent.s6;

import java.util.ArrayList;
import java.util.List;

//algorithm based on calculating the row values, it could be applied in the other way around
public class NumericSquareSolver {

	private static int minNum=0;
	private static int maxNum=9;

	
	public static void main(String[] args) {
		String text = "src/algstudent/s6/test05.txt";
		NumericSquare numericSquare = new NumericSquare(text);

		numericSquareAll(numericSquare);
		
		//printMatrixOfMatrixes(numericSquareAll(numericSquare));
		//numericSquareAll(numericSquare);
	}

	public static List<List<Integer>> numericSquareOne(NumericSquare numericSquare){
		
		String[] colOperations = numericSquare.getColumnOperations();
		
		List<List<List<Integer>>> allPossibleMatrixes = setUp(numericSquare);

		for (List<List<Integer>> matrix : allPossibleMatrixes) {
            if(isValidMatrix(matrix,colOperations)) {
            	System.out.println("First result found: ");
            	return matrix;
            }
        }
		
    	System.out.println("No result found. ");
		return null;
	}
	
	public static List<List<List<Integer>>> numericSquareAll(NumericSquare numericSquare){
		
		String[] colOperations = numericSquare.getColumnOperations();
		
		List<List<List<Integer>>> allPossibleMatrixes = setUp(numericSquare);

		List<List<List<Integer>>> allValidMatrixes=new ArrayList<>();
		
		for (List<List<Integer>> matrix : allPossibleMatrixes) {
            if(isValidMatrix(matrix,colOperations)) {
            	allValidMatrixes.add(matrix);;
            }
        }
		
		System.out.println("Number of results found: "+ allValidMatrixes.size());
		return allValidMatrixes;
	}
	
	//sets up based on the row, i uncomment colOperations and use rowOperations on the 
	//solving methods it should work too
	private static List<List<List<Integer>>> setUp(NumericSquare numericSquare){
		String[] rowOperations = numericSquare.getRowOperations();
		//String[] colOperations = numericSquare.getColumnOperations();
		
		//for 4x4; 4 rows, x soluciones para cada row, valores dentro de la ultima lista.
		List<List<List<Integer>>> rowSolutions = getRowOrColResults(rowOperations);
		//List<List<List<Integer>>> colSolutions = getRowOrColResults(colOperations);

		// list of matrixes with all possible row solutions
		List<List<List<Integer>>> allPossibleMatrixes = generateAllPossibleMatrixes(rowSolutions, 0);
		
		return allPossibleMatrixes;
		
	}

	//for a given matrix checks if those values are also valid for column results
	private static boolean isValidMatrix(List<List<Integer>> matrix, String[] rowOrColOperations) {
		
		//printMatrix(matrix);
		
		for(int j=0; j<matrix.size();j++) {
			List <Integer>column= new ArrayList<>();
			for(int i=0; i<matrix.size();i++) {
				column.add(matrix.get(i).get(j));
			}
			if(!isValidRowOrColumn(column, rowOrColOperations[j])){
				return false;
			}
		}
		
		return true;
	}

	//checks if the values are valid for a given column or row
	private static boolean isValidRowOrColumn(List<Integer> values, String operation) {
		
		List<Character> operators = getOperators(operation);
		int expectedValue= getExpectedResult(operation);
		
		int result = calculateResult(values, operators);
		
		return expectedValue==result;
	}

	/*
	 *gets the list of all results of the operations of a matrix rows or columns
	 */
	private static List<List<List<Integer>>> getRowOrColResults(String [] rowOrColOperations) {

		List<List<List<Integer>>> rowOrColSolutions = new ArrayList<>();

		for(String operation : rowOrColOperations) {
			rowOrColSolutions.add(getOperationResults(operation));
		}

		return rowOrColSolutions;
	}

	/*gets all the results for a given operation*/
	private static List<List<Integer>> getOperationResults(String operation) {

		List<Integer> values = getValues(operation);
		List<Character> operators = getOperators(operation);
		int expectedValue= getExpectedResult(operation);

		List<List<Integer>> allCombinations = getAllValidCombinations(values, 0, minNum, maxNum,operators,expectedValue);

		/* for (List<Integer> combination : allCombinations) {
	        System.out.println(combination);
	    }*/

		return allCombinations;

	}

	/*Expected result of a operation, checks after the =*/
	private static int getExpectedResult(String operation) {
		String[] parts = operation.split("=");
		return Integer.parseInt(parts[1].trim());
	}

	/*Get the values of the operation, the ones we are interested in computing*/
	private static List<Integer> getValues(String operation) {
		String[] parts = operation.split("=");

		String operationValuesNoResult=parts[0];
		List<Integer> operationValues = new ArrayList<>();

		for (int i = 0; i < operationValuesNoResult.length(); i += 2) { // Increment by 2 to skip operators
			char valueAsChar = operationValuesNoResult.charAt(i);
			if (valueAsChar == '?') {
				operationValues.add(-1);
			}
			else if (valueAsChar == '=') {
				return operationValues;
			} 
			else {
				int value = Character.getNumericValue(valueAsChar);
				operationValues.add(value);
			}
		}
		return operationValues;
	}

	/*Gets the operators of a operation except =*/
	private static List<Character> getOperators(String operation) {

		String[] parts = operation.split("=");

		String operationOperatorsNoEquals=parts[0];

		List<Character> operationOperators = new ArrayList<>();
		operationOperators.add(' ');

		for (int i = 1; i < operationOperatorsNoEquals.length(); i += 2) { // Increment by 2 to skip operators
			char operator=operationOperatorsNoEquals.charAt(i);

			operationOperators.add(operator);
		}

		return operationOperators;
	}

	/*Gets all the possible VALID combinations for a given row or column*/
	private static List<List<Integer>> getAllValidCombinations(List<Integer> values, int index, int minNum, int maxNum,List<Character> operators, int expectedValue) {
		List<List<Integer>> allValues = new ArrayList<>();

		if (index == values.size()) {
			int result = calculateResult(values, operators);
			

			if (result == expectedValue) {
				allValues.add(new ArrayList<>(values)); // If the result matches the expected value, add the combination
			}
			return allValues;
		}

		int value = values.get(index);

		if (value == -1) {
			for (int i = minNum; i <= maxNum; i++) {
				values.set(index, i);
				List<List<Integer>> combinations = getAllValidCombinations(new ArrayList<>(values), index + 1, minNum, maxNum,operators,expectedValue);
				allValues.addAll(combinations);
			}
		} else {
			List<List<Integer>> combinations = getAllValidCombinations(new ArrayList<>(values), index + 1, minNum, maxNum,operators,expectedValue);
			allValues.addAll(combinations);
		}

		return allValues;
	}

	/*Calculates the result of a given set of values, given the operators of the original operation
	 * 
	 * Uses recursion storing result and passing the operators
	 */
	private static int calculateResult(List<Integer> values, List<Character> operators) {
		int result = values.get(0);
		for (int i = 1; i < values.size(); i++) {
			char operator = operators.get(i);
			int value = values.get(i);

			if (value != -1) { // Check if the value is not a placeholder
				result = calculateResult(result, value, operator);
			}
		}
		return result;
	}

	// generate matrixes row0 sol0,row1 sol0, row0 sol0, 
	//then ->row0 sol0,row1 sol1, row2 sol0 and so on
	private static List<List<List<Integer>>> generateAllPossibleMatrixes(List<List<List<Integer>>> rowSolutions, int row) {
		List<List<List<Integer>>> allPossibleMatrixes = new ArrayList<>();

		// if last row return last obtained set of matrixes
		if (row == rowSolutions.size() - 1) {
			for (List<Integer> rowSol : rowSolutions.get(row)) {
				List<List<Integer>> matrix = new ArrayList<>();
				matrix.add(rowSol);
				allPossibleMatrixes.add(matrix);
			}
			return allPossibleMatrixes;
		}

		//join the following rowOfRows to the already obtained one/s
		for (List<Integer> rowSol : rowSolutions.get(row)) {

			List<List<List<Integer>>> nextRowMatrixes = generateAllPossibleMatrixes(rowSolutions, row + 1);

			for (List<List<Integer>> nextRowMatrix : nextRowMatrixes) {
				List<List<Integer>> matrix = new ArrayList<>();
				matrix.add(rowSol);
				matrix.addAll(nextRowMatrix);
				allPossibleMatrixes.add(matrix);
			}
		}

		return allPossibleMatrixes;
	}

	/*Logic for the operators, a is the accumulative result, b is the next evaluated value*/
	private static int calculateResult(int a, Integer b, Character operator) {
		if(operator=='+')
			return a+b;
		else if(operator=='-')
			return a-b;
		else if(operator=='*')
			return a*b;
		else if(operator=='/')
			if(b==0 || a%b!=0 ) {
				return 0;
			}
			else 
				return a/b;
		else
			throw new IllegalArgumentException("Invalid operator");
	}

	@SuppressWarnings("unused")
	private static void printDetails(List<Integer> values, List<Character> operators, int expectedValue, String operation) {
		System.out.println("Operation:  " + operation);
		System.out.print("Values: ");
		for (int value : values) {
			if (value == -1) {
				System.out.print("? ");
			} else {
				System.out.print(value + " ");
			}
		}
		System.out.println();

		System.out.print("Operators: ");
		for (char operator : operators) {
			System.out.print(operator + " ");
		}
		System.out.println();

		System.out.println("Expected Result: " + expectedValue);
		System.out.println();
	}

	
	 static void printMatrix(List<List<Integer>> matrix) {
		for (List<Integer> row : matrix) {
			System.out.println(row);
		}
		System.out.println();
	}
	
	
	 static void printMatrixOfMatrixes(List<List<List<Integer>>> matrixes) {
		for (List<List<Integer>> matrix : matrixes) {
			for (List<Integer> row : matrix) {
				System.out.println(row);
			}
			System.out.println();
		System.out.println();
		}
	}

}
