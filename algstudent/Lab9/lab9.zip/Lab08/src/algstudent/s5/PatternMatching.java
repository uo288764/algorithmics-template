package algstudent.s5;

public class PatternMatching {

	private String pattern;
	private boolean [][] matrix ;
	private String outerFile;
	
	public PatternMatching(String text) {
		this.pattern = text;
		pattern=' '+pattern;
		
	}

	//return last right
	public boolean checkPattern(String text) {
	    this.outerFile = text;
	    outerFile = ' ' + outerFile;

	    int rows = outerFile.length();
	    int cols = pattern.length();
	    this.matrix = new boolean[rows][cols];
	    matrix[0][0] = true;

	    
	    for (int i = 1; i < rows ; i++) {
	        for (int j = 1; j < cols; j++) {
	           
	            // Case II: When both letters do match
	            if (pattern.charAt(j) == outerFile.charAt(i)) {
		            // Case I: if the pattern is empty, it will only match the text if the text is also empty
	            	if(pattern.charAt(j)==' ')
	            		matrix[i][j] = true;
	            	else
	            		matrix[i][j]=matrix[i-1][j-1];
	            }
	            // Case III: When both letters do not match -> false, no need, matrix initialized to false
	            
	            // Case IV: When we find a ?
	            // previous row and previous column or same row previous column match -> true
	            //think there was a typo on the pdf, as it does work with 
	            //previous row and previous column or previous row same column match
	            if (pattern.charAt(j) == '?' || outerFile.charAt(i)=='?') {
                    if (matrix[i-1][j] || matrix[i - 1][j -1]) {
                    	matrix[i][j] = true;
                    }
                }
	            //Case V: we find *
	            //previous row and previous column, same row previous column,
	            //or previous row same column match-> true
	            if (pattern.charAt(j) == '*'|| outerFile.charAt(i)=='*') {
                    if (matrix[i][j - 1] || matrix[i - 1][j - 1] || matrix[i - 1][j]) {
                    	matrix[i][j] = true;
                    }
                }

	        }
	    }

	    return matrix[outerFile.length() - 1][pattern.length() - 1];
	}
	
	public void printsTable() {
		System.out.println();
	    System.out.print("  ");
	    for (int k = 0; k < pattern.length(); k++) {
	        System.out.print(pattern.charAt(k) + " ");
	    }
	    System.out.println();

	    for (int i = 0; i < matrix.length; i++) {
	        System.out.print(outerFile.charAt(i) + " ");

	        for (int j = 0; j < matrix[0].length; j++) {
	            if (matrix[i][j]) {
	                System.out.print("T ");
	            } else {
	                System.out.print("F ");
	            }
	        }
	        System.out.println();
	    }
	    System.out.println();
	}
}
