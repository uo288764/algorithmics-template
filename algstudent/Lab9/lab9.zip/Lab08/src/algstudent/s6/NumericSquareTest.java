package algstudent.s6;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class NumericSquareTest {
	String text;
	String matrix[][];
	int size;
	
	public void test1() {
		loadData("src/algstudent/s6/test00.txt");		
		NumericSquare numericSquare = new NumericSquare(text);		
		numericSquare.printMatrix();
		
	}
	
	
	private void loadData(String file) {
		BufferedReader reader = null;	

		try {
			reader = new BufferedReader(new FileReader(file));
			this.size = Integer.parseInt(reader.readLine()); 
			
			this.size = Integer.parseInt(reader.readLine());

			this.matrix = new String[this.size][this.size];
			
			int counter=0;
			while (reader.ready()) {
				String[] parts = reader.readLine().split(" ");
				
				for(int i=0;i<parts.length;i++) {
					matrix[counter][i]=parts[i];
					counter++;
				}
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
