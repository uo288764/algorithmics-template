package algstudent.s6;

public class NumericSquareOne {

	public static void main(String []args) {
		
		String text=("src/algstudent/s6/test00.txt");		
		NumericSquare numericSquare = new NumericSquare(text);		
		numericSquare.printMatrix();
	}
}
