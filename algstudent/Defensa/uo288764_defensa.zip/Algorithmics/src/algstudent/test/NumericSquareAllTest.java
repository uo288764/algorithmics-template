package algstudent.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class NumericSquareAllTest {
	
	@BeforeEach
    public void printSeparator() {
        System.out.println("----------------------------------------------");
    }

	@Test
	void test00() {
	    String text = "src/algstudent/test/test00.txt";
	    NumericSquare numericSquare = new NumericSquare(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareSolver.backtrackAllSolutions(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    
	    int results= numericSquare.getNumberOfSols();
	    System.out.println("test00 - Execution time: " + executionTime + " ms. Results = "+results);
	    System.out.println();
	}

	@Test
	void test01() {
	    String text = "src/algstudent/test/test01.txt";
	    NumericSquare numericSquare = new NumericSquare(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareSolver.backtrackAllSolutions(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    int results= numericSquare.getNumberOfSols();

	    System.out.println("test01 - Execution time: " + executionTime + " ms. Results = "+results);
	    System.out.println();
	}

	@Test
	void test02() {
	    String text = "src/algstudent/test/test02.txt";
	    NumericSquare numericSquare = new NumericSquare(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareSolver.backtrackAllSolutions(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    int results= numericSquare.getNumberOfSols();

	    System.out.println("test02 - Execution time: " + executionTime + " ms. Results = "+results);
	    System.out.println();
	}

	/*@Test
	void test03() {
	    String text = "src/algstudent/s7/test03.txt";
	    NumericSquare numericSquare = new NumericSquare(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareSolver.backtrackAllSolutions(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    int results= numericSquare.getNumberOfSols();

	    System.out.println("test03 - Execution time: " + executionTime + " ms. Results = "+results);
	    //NumericSquareSolver.printMatrixOfMatrixes(solution);
	    System.out.println();
	}

	@Test
	void test04() {
	    String text = "src/algstudent/s7/test04.txt";
	    NumericSquare numericSquare = new NumericSquare(text);
	    
	    long startTime = System.currentTimeMillis();
	   NumericSquareSolver.backtrackAllSolutions(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    
	    int results= numericSquare.getNumberOfSols();
	    System.out.println("test04 - Execution time: " + executionTime + " ms. Results = "+results);
	    System.out.println();
	}

	@Test
	void test05() {
	    String text = "src/algstudent/s7/test05.txt";
	    NumericSquare numericSquare = new NumericSquare(text);
	    
	    long startTime = System.currentTimeMillis();
	     NumericSquareSolver.backtrackAllSolutions(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    
	    int results= numericSquare.getNumberOfSols();
	    System.out.println("test05 - Execution time: " + executionTime + " ms. Results = "+results);
	    System.out.println();
	}

	@Test
	void test06() {
	    String text = "src/algstudent/s7/test06.txt";
	    NumericSquare numericSquare = new NumericSquare(text);
	    
	    long startTime = System.currentTimeMillis();
	     NumericSquareSolver.backtrackAllSolutions(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    
	    int results= numericSquare.getNumberOfSols();
	    System.out.println("test06 - Execution time: " + executionTime + " ms. Results = "+results);
	    System.out.println();
	}

	//@Test
	void test07() {
	    String text = "src/algstudent/s7/test07.txt";
	    NumericSquare numericSquare = new NumericSquare(text);
	    
	    long startTime = System.currentTimeMillis();
	    NumericSquareSolver.backtrackAllSolutions(numericSquare);
	    long endTime = System.currentTimeMillis();
	    
	    long executionTime = endTime - startTime;
	    
	    int results= numericSquare.getNumberOfSols();
	    System.out.println("test07 - Execution time: " + executionTime + " ms. Results = "+results);
	    System.out.println();
	}*/

}
