package algstudent.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

//algorithm based on calculating the row values, it could be applied in the other way around
public class NumericSquareSolver {

	private static int minNum=-5;
	private static int maxNum=5;
	private static int expectedDiagonalSum=0;
	

	public static void main(String[] args) {
		String text = "src/algstudent/s7/test01.txt";
		NumericSquare numericSquare = new NumericSquare(text);

		backtrackOneSolution(numericSquare);
		//backtrackAllSolutions(numericSquare);
		
	}
	
	public static void backtrackOneSolution(NumericSquare numericSquare) {
		
		String [] rowOperations=numericSquare.getRowOperations();
		String [] colOperations= numericSquare.getColumnOperations();
		
		getMatrixValues(rowOperations, numericSquare);
		
		AtomicBoolean foundSolution= new AtomicBoolean(false);
		backtracking(numericSquare.getValueMatrix(), rowOperations, colOperations, numericSquare, true,foundSolution);
	}

	public static void backtrackAllSolutions(NumericSquare numericSquare) {
		
		String [] rowOperations=numericSquare.getRowOperations();
		String [] colOperations= numericSquare.getColumnOperations();
		
		getMatrixValues(rowOperations, numericSquare);
		
		AtomicBoolean foundSolution= new AtomicBoolean(false);

		backtracking(numericSquare.getValueMatrix(), rowOperations, colOperations, numericSquare, false,foundSolution);
		System.out.println("Solutions found: "+ numericSquare.getNumberOfSols());
	}

	private static void backtracking(int[][] valueMatrix, String[] rowOperations, String[] colOperations, NumericSquare numericSquare,
			boolean oneSolution,AtomicBoolean foundSolution) {
		
		int [][] aux = new int [valueMatrix.length][valueMatrix[0].length];
		
		backtrack(aux, valueMatrix, 0, 0,  rowOperations, colOperations,numericSquare, oneSolution, foundSolution);
	}


	private static void backtrack(int[][] aux, int[][] valueMatrix, int i, int j, String[] rowOperations, 
					String[] colOperations, NumericSquare numericSquare, boolean oneSolution, AtomicBoolean foundSolution) {
		//case for just finding one solution, if found return
		if(oneSolution && foundSolution.get()) {
			return;
		}
				
	    // Base case: end of the matrix
	    if (i == valueMatrix.length - 1 && j == valueMatrix[0].length - 1) {
	        if (valueMatrix[i][j] == -1) {
	            for (int k = minNum; k <= maxNum; k++) {
	                aux[i][j] = k;
	                if(isValidRow(aux, rowOperations[i], i) && isValidCol(aux, colOperations[j], j)
	                		&& isValidDiagonal(aux)){ 
	                	printMatrix(aux);
	                	
	                	if(numericSquare.getSolutions().add(serialize(aux))) {
	                		numericSquare.setNumberOfSols(numericSquare.getNumberOfSols() + 1);
	                		System.out.println("solution: "+ numericSquare.getNumberOfSols());
	                		foundSolution.set(true);}
	                }
	            }
	        }//==-1 
	        else {
	        	
	            aux[i][j] = valueMatrix[i][j];
	            if(isValidRow(aux, rowOperations[i], i) && isValidCol(aux, colOperations[j], j)
                		&& isValidDiagonal(aux)){ 
                	printMatrix(aux);
                	
                	if(numericSquare.getSolutions().add(serialize(aux))) {
                		numericSquare.setNumberOfSols(numericSquare.getNumberOfSols() + 1);
                		System.out.println("solution: "+ numericSquare.getNumberOfSols());
                		foundSolution.set(true);}
                }
            }
	        
	        return;
	    }

	    // recursive calls
	    if (valueMatrix[i][j] == -1) { //value is -1, then loop 0-9
	        for (int k = minNum; k <= maxNum; k++) {
	            aux[i][j] = k;
	            if (j == valueMatrix[0].length - 1) {//last col cell, check row
	                if (isValidRow(aux, rowOperations[i], i)) {
	                    backtrack(aux, valueMatrix, i + 1, 0, rowOperations, colOperations, numericSquare, oneSolution, foundSolution);
	                }
	            } 
	            else {
	                if (i == valueMatrix.length - 1) {//last row, check columns
	                    if (isValidCol(aux, colOperations[j], j)) {//if valid, move to next col
	                        backtrack(aux, valueMatrix, i, j + 1, rowOperations, colOperations, numericSquare,oneSolution, foundSolution);
	                    }
	                } 
	                else {//move to next col
	                    backtrack(aux, valueMatrix, i, j + 1, rowOperations, colOperations, numericSquare,oneSolution, foundSolution);
	                }
	            }
	        }
	    } 
	    else {
	        aux[i][j] = valueMatrix[i][j];
	        if (j == valueMatrix[0].length - 1) {//last col cell, check row
	            if (isValidRow(aux, rowOperations[i], i)) {//if valid row, move to next row
	                backtrack(aux, valueMatrix, i + 1, 0, rowOperations, colOperations, numericSquare,oneSolution, foundSolution);
	            }
	        } 
	        else {
	            if (i == valueMatrix.length - 1) {//last row, check columns
	                if (isValidCol(aux, colOperations[j], j)) {//if valid col, next row
	                    backtrack(aux, valueMatrix, i, j + 1, rowOperations, colOperations, numericSquare,oneSolution, foundSolution);
	                }
	            } else {//move to next col
	                backtrack(aux, valueMatrix, i, j + 1, rowOperations, colOperations, numericSquare,oneSolution, foundSolution);
	            }
	        }
	    }
	}

	//sets the matrix of values in NumericSquares
	public static void getMatrixValues(String [] rowOperations, NumericSquare numericSquare){
		
		 int [][] matrix = new int[rowOperations.length][getValues(rowOperations[0]).size()];
		
		for( int i =0; i< rowOperations.length;i++) {
			
			List<Integer> row = getValues(rowOperations[i]);
			
			for(int j=0; j<row.size();j++) {
				matrix[i][j]=row.get(j);
			}
		}
		
		numericSquare.setValueMatrix(matrix);
	}
	

	/*Get the values of the operation, the ones we are interested in computing*/
	private static List<Integer> getValues(String operation) {
		String[] parts = operation.split("=");

		String operationValuesNoResult=parts[0];
		List<Integer> operationValues = new ArrayList<>();

		for (int i = 0; i < operationValuesNoResult.length(); i += 2) { // Increment by 2 to skip operators
			char valueAsChar = operationValuesNoResult.charAt(i);
			if (valueAsChar == '?') {
				operationValues.add(-1);
			}
			else if (valueAsChar == '=') {
				return operationValues;
			} 
			else {
				int value = Character.getNumericValue(valueAsChar);
				operationValues.add(value);
			}
		}
		return operationValues;
	}

	/*Gets the operators of a operation except =*/
	private static List<Character> getOperators(String operation) {

		String[] parts = operation.split("=");

		String operationOperatorsNoEquals=parts[0];

		List<Character> operationOperators = new ArrayList<>();
		operationOperators.add(' ');

		for (int i = 1; i < operationOperatorsNoEquals.length(); i += 2) { // Increment by 2 to skip operators
			char operator=operationOperatorsNoEquals.charAt(i);

			operationOperators.add(operator);
		}

		return operationOperators;
	}

	private static int getExpectedResult(String operation) {
		String[] parts = operation.split("=");
		return Integer.parseInt(parts[1].trim());
	}
	
	private static boolean isValidRow(int[][] aux, String operation,int rowIndex) {
		
		List<Character> operators = getOperators(operation);
		int expectedValue= getExpectedResult(operation);
		
		int result = calculateRowResult(aux,operators,rowIndex);
		
		return expectedValue==result;
	}
	
	private static boolean isValidCol(int[][] aux, String operation,int colIndex) {
		
		List<Character> operators = getOperators(operation);
		int expectedValue= getExpectedResult(operation);
		
		int result = calculateColResult(aux,operators,colIndex);
		
		return expectedValue==result;
	}
	
	private static boolean isValidDiagonal(int[][] aux) {
		int result=0;
		
		for(int i=0;i<aux.length;i++) {
			result+=aux[i][i];
		}
		
		return result==expectedDiagonalSum;
	}


	/*Calculates the result of a given set of values, given the operators of the original operation
	 * 
	 * Uses recursion storing result and passing the operators
	 */
	private static int calculateRowResult(int[][] aux, List<Character> operators, int rowIndex) {
	
	    int[] values = aux[rowIndex];
	    
		
		int result = values[0];
		for (int i = 1; i < values.length; i++) {
			char operator = operators.get(i);
			int value = values[i];

			if (value != -1) { // Check if the value is not a placeholder
				result = calculateResult(result, value, operator);
			}
		}
		return result;
	}
	
	private static int calculateColResult(int[][] aux, List<Character> operators, int colIndex) {

		int numRows = aux.length;
		int[] values = new int[numRows];


		for (int i = 0; i < numRows; i++) {
			values[i] = aux[i][colIndex];
		}


		int result = values[0];
		for (int i = 1; i < values.length; i++) {
			char operator = operators.get(i);
			int value = values[i];

			if (value != -1) { // Check if the value is not a placeholder
				result = calculateResult(result, value, operator);
			}
		}
		return result;
	}

	/*Logic for the operators, a is the accumulative result, b is the next evaluated value*/
	private static int calculateResult(int a, Integer b, Character operator) {
		if(operator=='+')
			return a+b;
		else if(operator=='-')
			return a-b;
		else if(operator=='*')
			return a*b;
		else if(operator=='/')
			if(b==0 || a % b!=0 ) {
				return 1000;
				//throw new IllegalArgumentException("Invalid operation"); 
			}
			else 
				return a/b;
		else
			throw new IllegalArgumentException("Invalid operator");
	}

	@SuppressWarnings("unused")
	private static void printDetails(List<Integer> values, List<Character> operators, int expectedValue, String operation) {
		System.out.println("Operation:  " + operation);
		System.out.print("Values: ");
		for (int value : values) {
			if (value == -1) {
				System.out.print("? ");
			} else {
				System.out.print(value + " ");
			}
		}
		System.out.println();

		System.out.print("Operators: ");
		for (char operator : operators) {
			System.out.print(operator + " ");
		}
		System.out.println();

		System.out.println("Expected Result: " + expectedValue);
		System.out.println();
	}

	
	 static void printMatrix(int[][] matrix) {
	        int rows = matrix.length;
	        int cols = matrix[0].length;

	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                System.out.print(matrix[i][j] + " ");
	            }
	            System.out.println();
	        }
	        System.out.println();
	    }
	 
	 static String serialize(int[][] matrix) {
	        int rows = matrix.length;
	        int cols = matrix[0].length;

	        String aux="";
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	               aux+=matrix[i][j] + " ";
	            }
	            
	        }
	       return aux;
	    }
	
	
	 static void printMatrixOfMatrixes(List<List<List<Integer>>> matrixes) {
		for (List<List<Integer>> matrix : matrixes) {
			for (List<Integer> row : matrix) {
				System.out.println(row);
			}
			System.out.println();
		System.out.println();
		}
	}

}
